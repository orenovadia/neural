import matplotlib.pyplot as plt
import numpy as np
from sklearn import linear_model

def sigmoid(z):
    return 1 / (1 + np.exp(-z))


def hypothesis(theta, X):
    return sigmoid(theta.T.dot(X.T))


def cost_function(theta, X, y, m):
    J = 1.0 / (2.0 * m) * np.sum((hypothesis(theta, X).ravel() - y) ** 2)
    print (hypothesis(theta, X).ravel() ** 2).shape
    print np.shape(y)
    return J

def gradient_decent(X, y, theta, alpha, iterations):
    J_history = np.ndarray([iterations, 1])
    m = len(y)
    for i in xrange(iterations):
        J_history[i] = compute_cost(X, y, theta)
        theta = theta + alpha * compute_gradient(X, y, theta, m)
        # print np.sum( np.sum(theta.dot(X) - y) * X ,1).shape,theta.shape
        # print (np.sum(theta.dot(X) - y) * X ).sum(1).shape,y.shape
        # print np.sum( (theta.dot(X) - y).dot(X.T) ,0).T.shape
    return theta, J_history

data = np.loadtxt('ex2data1.txt', delimiter=',')
X = data[:, :2]
y = data[:, 2]
plt.scatter(X[:, 0], X[:, 1], s=40, c=(y * 200 + 3), alpha=0.5)
m, n = X.shape
X = np.hstack((np.ones((m, 1)), X))
initial_theta = np.zeros((n + 1, 1))
# plt.show()
print cost_function(initial_theta, X, y, m)
clf = linear_model.LogisticRegression()
print clf
print clf.fit(X,y)
print X.shape
print clf.coef_
print clf.predict(np.array([1,100,100]))